# 藍新金流 SDK (v1.0)

。藍新金流API文件　https://www.newebpay.com/dw_files/info_api/spgateway_gateway_MPGapi_V1_0_3.pdf

。藍新測試後台：https://ccore.newebpay.com/

。藍新測試信用卡號：4000-2211-1111-1111／到期日與未三碼，隨意填寫



使用說明：

1.開啟conf.php，分別輸入商店代號、HashKey、HashIV

2.設定商店相對應網址

3.設定產品名稱與金額

4.當要進入付款頁面時，在atm.php?pay=y，就會自動跳轉至藍新的結帳頁面
