<?php

return [
    'name' => 'Woocommerce',
    'module_version' => "0.9"
];
