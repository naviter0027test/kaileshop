<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Brand Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for Brand CRUD operations.
    |
    */

    'categories'=>'類別',
    'manage_your_categories'=>'管理您的類別',
    'all_your_categories'=>'所有類別',
    'category'=>'類別',
    'category_name'=>'類別名稱',
    'code'=>'類別代碼',
    'add_as_sub_category'=>'添加為子類',
    'select_parent_category'=>'選擇父類別',
    'added_success'=>'類別已成功添加',
    'updated_success'=>'類別已成功更新',
    'deleted_success'=>'類別已成功刪除',
    'add_category'=>'添加類別',
    'edit_category'=>'編輯類別'
];
