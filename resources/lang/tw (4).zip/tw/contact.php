<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Contact Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during Contacts CRUD operations.
    |
    */

    'contacts'=>'聯繫人',
    'name'=>'姓名',
    'contact'=>'聯繫',
    'manage_your_contact'=>'管理您的 :contacts',
    'all_your_contact'=>'你的全部 :contacts',
    'add_contact'=>'添加新聯繫人',
    'contact_type'=>'聯繫人類型',
    'tax_no'=>'稅號',
    'pay_term'=>'付款期限',
    'pay_term_period'=>'付款期限',
    'mobile'=>'移動',
    'landline'=>'固定電話',
    'alternate_contact_number'=>'替代聯繫電話',
    'edit_contact'=>'編輯聯繫人',
    'added_success'=>'聯繫人已成功添加',
    'updated_success'=>'聯繫人已成功更新',
    'deleted_success'=>'聯繫人已成功刪除',
    'add_new_customer'=>'添加新客戶',
    'view_contact'=>'查看聯繫人',
    'contact_info'=>':contact info',
    'all_purchases_linked_to_this_contact'=>'與此聯繫人相關的所有購買',
    'all_sells_linked_to_this_contact'=>'所有與此聯繫人相關的銷售',
    'total_purchase_due'=>'總購買金額',
    'pay_due_amount'=>'支付到期金額',
    'total_paid'=>'付費總額',
    'total_purchase_paid'=>'總購買付款',
    'total_sale_paid'=>'總銷售付款',
    'total_sale_due'=>'總銷售到期',
    'customer'=>'客戶'
];
